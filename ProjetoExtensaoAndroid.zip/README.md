# Projeto de Extensão Android

Aplicativo Android de exemplo para controle de vendas e estoque da Lanchonete Sabor da Praça Ltda.

## Funcionalidades
- Cadastro de produtos
- Registro de vendas
- Controle de estoque
- Relatórios simples

## Tecnologias
- Kotlin
- Jetpack Compose
- Room (persistência local)

## Como usar
Abra no Android Studio (versão Arctic Fox ou superior) e rode em um emulador ou dispositivo físico.
