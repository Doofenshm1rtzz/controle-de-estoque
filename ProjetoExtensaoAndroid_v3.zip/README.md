# Projeto Extensão - Sabor da Praça

Abra no Android Studio e rode em um emulador (AVD) ou dispositivo.
