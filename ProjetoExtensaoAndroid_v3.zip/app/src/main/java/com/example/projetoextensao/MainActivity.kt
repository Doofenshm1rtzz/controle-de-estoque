package com.example.projetoextensao

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Room
import com.example.projetoextensao.data.AppDatabase
import com.example.projetoextensao.ui.AppViewModel
import com.example.projetoextensao.ui.AppViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "projeto-db").build()
        setContent {
            val vm: AppViewModel = viewModel(factory = AppViewModelFactory(db))
            Scaffold(topBar = { TopAppBar(title = { Text("Sabor da Praça - Demo") }) }) {
                Box(modifier = Modifier.padding(16.dp)) {
                    AppContent(vm)
                }
            }
        }
    }
}

@Composable
fun AppContent(vm: AppViewModel) {
    val products by vm.products.collectAsState()
    var name by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }

    Column {
        Text("Cadastro de produto", style = MaterialTheme.typography.h6)
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nome") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("Preço") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = qty, onValueChange = { qty = it }, label = { Text("Quantidade") }, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {
            val p = price.toDoubleOrNull() ?: 0.0
            val q = qty.toIntOrNull() ?: 0
            vm.addProduct(name, p, q)
            name = ""; price = ""; qty = ""
        }) { Text("Salvar") }
        Spacer(modifier = Modifier.height(16.dp))
        Text("Produtos", style = MaterialTheme.typography.h6)
        products.forEach { pr ->
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${'$'}{pr.name} - ${'$'}{pr.quantity} un - R$ ${'$'}{String.format("%.2f", pr.price)}")
                Row {
                    Button(onClick = { vm.decreaseStock(pr.id,1) }) { Text("-") }
                    Button(onClick = { vm.increaseStock(pr.id,1) }) { Text("+") }
                }
            }
        }
    }
}
