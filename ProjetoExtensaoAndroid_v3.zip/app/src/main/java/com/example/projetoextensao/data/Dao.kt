package com.example.projetoextensao.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM Product")
    fun getProducts(): Flow<List<Product>>

    @Insert
    suspend fun insertProduct(p: Product): Long

    @Update
    suspend fun updateProduct(p: Product)

    @Query("DELETE FROM Product WHERE id = :id")
    suspend fun deleteProductById(id: Int)

    @Query("SELECT * FROM Sale")
    fun getSales(): Flow<List<Sale>>

    @Insert
    suspend fun insertSale(s: Sale)
}
