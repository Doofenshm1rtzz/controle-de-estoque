package com.example.projetoextensao.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.projetoextensao.data.AppDatabase
import com.example.projetoextensao.data.Product
import com.example.projetoextensao.data.Sale
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(private val db: AppDatabase) : ViewModel() {
    private val dao = db.appDao()
    val products: StateFlow<List<Product>> = dao.getProducts().map { it }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val sales: StateFlow<List<Sale>> = dao.getSales().map { it }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun addProduct(name: String, price: Double, quantity: Int) {
        viewModelScope.launch { dao.insertProduct(Product(name = name, price = price, quantity = quantity)) }
    }

    fun deleteProduct(id: Int) { viewModelScope.launch { dao.deleteProductById(id) } }

    fun increaseStock(id: Int, by: Int) { viewModelScope.launch {
        val list = products.value
        val p = list.find { it.id == id } ?: return@launch
        dao.updateProduct(p.copy(quantity = p.quantity + by))
    } }

    fun decreaseStock(id: Int, by: Int) { viewModelScope.launch {
        val list = products.value
        val p = list.find { it.id == id } ?: return@launch
        val newQty = (p.quantity - by).coerceAtLeast(0)
        dao.updateProduct(p.copy(quantity = newQty))
    } }

    fun registerSale(productId: Int, quantity: Int) { viewModelScope.launch {
        val prod = products.value.find { it.id == productId } ?: return@launch
        if (prod.quantity < quantity) return@launch
        val total = prod.price * quantity
        dao.insertSale(Sale(productId = productId, quantity = quantity, total = total))
        dao.updateProduct(prod.copy(quantity = prod.quantity - quantity))
    } }
}

class AppViewModelFactory(private val db: AppDatabase) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AppViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AppViewModel(db) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
