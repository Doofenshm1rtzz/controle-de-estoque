// top-level build
plugins { kotlin("jvm") version "1.8.0" apply false }
