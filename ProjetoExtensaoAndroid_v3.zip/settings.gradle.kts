rootProject.name = "ProjetoExtensaoAndroid"
include(":app")
